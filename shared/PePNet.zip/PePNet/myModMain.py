# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
import matplotlib.pyplot as plt
import numpy as np

from util import *
#from myModel import *
from setting import *
from LSTMLongShortTerm import *
#from LSTM1Dim import *
#from LSTMAttention import *
#from transformer import *
#from ARIMAPart import *
# Press the green button in the gutter to run the script.


def recordDataset(dataset,name,pLen,tLLen,tSLen,term):
    lx,sx,y,ty,mask=divideDatasetSample(dataset,pLen,tLLen,tSLen,term)
    lx=np.array(lx)
    sx=np.array(sx)
    y=np.array(y)
    ty=np.array(ty)
    mask=np.array(mask)
    np.save(name+"lx.npy",lx)
    np.save(name+"sx.npy",sx)
    np.save(name+"y.npy",y)
    np.save(name+"ty.npy",ty)
    np.save(name+"mask.npy",mask)


def loadDataset(name):
    lx=np.load(name+"lx.npy",allow_pickle=True)#feaLen,setNum,tLen
    sx=np.load(name+"sx.npy",allow_pickle=True)#feaLen,setNum,pLen
    y=np.load(name+"y.npy",allow_pickle=True)#feaLen,setNum,pLen
    ty=np.load(name+"ty.npy",allow_pickle=True)#feaLen,setNum,pLen
    mask=np.load(name+"mask.npy",allow_pickle=True)#feaLen,setNum,pLen
    return lx,sx,y,ty,mask


if __name__ == '__main__':
    root="dataTermSample/"
    aliData = getCsvData(aliBigPath)
    print(len(aliData[0]),type(aliData))
    #cpuData = np.load("cpuData.npy", allow_pickle=True)
    #memData = np.load("memData.npy", allow_pickle=True)
    #cpuData=cpuData[:100]
    #memData=memData[:100]
    pLen=2
    tLLen=100#150
    tSLen=50#20
    trainChoice=0
    device = "cuda" if torch.cuda.is_available() else "cpu"
    """Tlen=getDataSetTerm(aliData)
    print(max(Tlen[0]),max(Tlen[1]))
    train,test,validate,term=getDataSetWithTerm(aliData,Tlen)

    recordDataset(train,root+"trainSet",pLen,tLLen,tSLen,term)
    recordDataset(test,root+"testSet",pLen,tLLen,tSLen,term)
    recordDataset(validate,root+"validate",pLen,tLLen,tSLen,term)"""
    train=loadDataset(root+"trainSet")
    test=loadDataset(root+"testSet")
    validate=loadDataset(root+"validate")
    MyLSTM(train,test,validate,pLen,tLLen,tSLen,trainChoice,device,seed=777635798)



# See PyCharm help at https://www.jetbrains.com/help/pycharm/
