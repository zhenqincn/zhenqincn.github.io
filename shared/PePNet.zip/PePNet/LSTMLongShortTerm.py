import torch.nn as nn
from torch.utils.data import Dataset
from torch.utils.data import DataLoader
import torch
import matplotlib.pyplot as plt
import os
import numpy as np
import random
import time
import datetime
from util import computeErro
from util import SMAPE
from util import RMSE
from util import MSE
from util import MAPE
from util import MAE

os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"
loadMod=False
needTrain=True
needPlot=True

#device = torch.device('cuda:1') if torch.cuda.is_available() else torch.device('cpu')

class myDataset(Dataset):
    def __init__(self,data,choice,pLen,tLLen,tSLen):
        super(myDataset, self).__init__()
        self.lx,self.sx,self.y,self.ty,self.mask=self.split(data,choice,pLen,tLLen,tSLen)

    def split(self,data,choice,pLen,tLLen,tSLen):
        lx=data[0]#feaLen,setNum,seqLen
        sx=data[1]#feaLen,setNum,seqLen
        y=data[2]
        ty=data[3]
        mask=data[4]
        lx=torch.tensor(lx[choice])/100#setNum,seqLen
        lx=lx[:,-tLLen:]
        sx=torch.tensor(sx[choice])/100#setNum,seqLen
        sx=sx[:,-tSLen:]
        y=torch.tensor(y[choice])/100#setNum,seqLen
        y=y[:,:pLen]
        ty=torch.tensor(ty[choice])/100
        ty=ty[:,:pLen]
        mask=torch.tensor(mask[choice])
        mask=mask[:,:pLen]
        lx=torch.unsqueeze(lx,2)
        sx=torch.unsqueeze(sx,2)
        y=torch.unsqueeze(y,2)
        ty=torch.unsqueeze(ty,2)
        mask=torch.unsqueeze(mask,2)
        #print(lx.shape,sx.shape,y.shape,ty.shape,mask.shape)
        #print(mask.sum())
        return lx,sx,y,ty,mask

    def __getitem__(self, item):
        item=item%self.__len__()
        return (self.lx[item],self.sx[item],self.y[item],self.ty[item],self.mask[item])

    def __len__(self):
        return len(self.lx)


class AttentionLayer(nn.Module):
    def __init__(self,qinSize,kinSize,vinSize,qkoSize,voSize):
        super(AttentionLayer, self).__init__()
        self.qW=nn.Linear(qinSize,qkoSize)
        self.kW=nn.Linear(kinSize,qkoSize)
        self.vW=nn.Linear(vinSize,voSize)
        self.activate=nn.Softmax(dim=2)
    def forward(self,query,key,value):
        query=self.qW(query)
        key=self.kW(key)
        value=self.vW(value)
        weight=self.activate(torch.matmul(query,key.transpose(-1,-2)))
        wei_val=torch.matmul(weight,value)
        return wei_val,weight


class multiHeadAttentionLayer(nn.Module):
    def __init__(self,qinSize,kinSize,vinSize,qkoSize,voSize,vlen):
        super(multiHeadAttentionLayer, self).__init__()
        self.atten1=AttentionLayer(qinSize,kinSize,vinSize,qkoSize,voSize)
        self.atten2=AttentionLayer(qinSize,kinSize,vinSize,qkoSize,voSize)
        self.atten3=AttentionLayer(qinSize,kinSize,vinSize,qkoSize,voSize)
        self.W=nn.Linear(vlen*3,vlen)
        self.qW=nn.Linear(vinSize,voSize)
    def forward(self,query,key,value):
        _,w1=self.atten1(query,key,value)
        _,w2=self.atten2(query,key,value)
        _,w3=self.atten3(query,key,value)
        value=self.qW(value)
        w=torch.cat([w1,w2,w3],dim=-1)
        w=self.W(w)
        wei_val=torch.matmul(w,value)
        return wei_val


class LSTMNeural(nn.Module):
    def __init__(self,inSize,oSize,hSize,lNum,tSLen,pLen,vLen):
        super(LSTMNeural, self).__init__()
        self.lstm1=nn.LSTM(inSize,hSize,lNum,batch_first=True,bias=True,dropout=0.2)
        self.lstm2 = nn.LSTM(inSize, hSize+16, lNum, batch_first=True,bias=True,dropout=0.2)
        self.linear1=nn.Linear(hSize,oSize,bias=True)
        self.linear2=nn.Linear(hSize+16,oSize,bias=True)
        self.lNum=lNum
        self.oSize=oSize
        self.hSize=hSize
        self.norm1=nn.LayerNorm(hSize)
        self.norm2=nn.LayerNorm(oSize)
        self.norm3=nn.LayerNorm(hSize+16)
        self.qW=nn.Linear(tSLen,pLen,bias=True)
        self.kW=nn.Linear(pLen,pLen,bias=True)
        self.vW=nn.Linear(pLen,pLen,bias=True)
        self.activate=nn.Softmax(dim=3)
        self.encoAtten=multiHeadAttentionLayer(1,1,1,16,16,vLen)
        self.affin=nn.Linear(hSize+16,hSize,bias=True)
        self.autoEncode=nn.Linear(pLen,int(pLen/2))
        self.autoDecode=nn.Linear(int(pLen/2),pLen)
        self.autoActivate=nn.ELU()
        self.decoAtten=multiHeadAttentionLayer(hSize,16,16,16,16,vLen)

    def forward(self,lx,sx,ty,pLen):
        batch, slen, fet = sx.shape
        #h=torch.randn((self.lNum,batch,self.oSize))
        #c=torch.randn((self.lNum,batch,self.hSize))
        res,(h,c)=self.lstm1(sx)
        res=self.norm1(res)
        res=self.linear1(res).view(batch,slen,fet)
        res=self.norm2(res)
        res=res[:,-1,:].view(batch,1,fet)
        wei_val=self.encoAtten(lx,lx,lx)
        pred=[]
        for i in range(pLen):
            th=h.transpose(0,1)#h:batch,numLayers*directionNum,hiddenSize
            tc=c.transpose(0,1)
            #print(th.shape)
            batch,numl,hsize=th.shape
            hc=torch.cat([th,tc],-2)
            dwei_val=self.decoAtten(hc,wei_val,wei_val)
            dh=dwei_val[:,:numl,:]
            dc=dwei_val[:,numl:,:]
            #print(dh.shape)
            #print(dc.shape)
            dh=dh.transpose(0,1)
            dc=dc.transpose(0,1)
            h=torch.cat([h,dh],-1)
            c=torch.cat([c,dc],-1)
            res,(h,c)=self.lstm2(res,(h,c))
            h = self.affin(h)
            c = self.affin(c)
            res=self.norm3(res)
            res=torch.reshape(res,[batch,-1])
            res=self.linear2(res).view(batch,1,fet)
            pred.append(res)
        pred=torch.cat(pred,1) #batch, seqLen, featLen
        sx=sx.transpose(1,2)#batch, feaLent, seqLen
        ty=ty.transpose(1,2)
        ty = self.autoEncode(ty)
        ty = self.autoActivate(ty)
        ty = self.autoDecode(ty)
        predT=pred.transpose(1,2)#batch, feaLen,seqLen
        query=self.qW(sx).unsqueeze(2) #batch, feaLen,1 , pLen
        kterm=self.kW(ty) #batch,feaLen, pLen
        kpred=self.kW(predT)#batch,feaLen,pLen
        key=torch.stack([kterm,kpred],dim=2)#batch,feaLen,2,pLen
        #print("key shape:",key.shape)
        vterm=self.vW(ty)#batch,feaLen,pLen
        product=torch.matmul(query,key.transpose(-1,-2))#batch,feaLen,1,2
        #print("product shape:",product.shape)
        weight=self.activate(product)#batch,feaLen,1,2
        value=torch.stack([vterm,predT],2)#batch,feaLen,2,pLen
        #print("value shape:",value.shape)
        value=value.transpose(-1,-2)#batch,feaLen,pLen,2
        weight=weight.transpose(-1,-2)#batch,feaLen,2,1
        predict=torch.matmul(value,weight)#batch,feaLen,pLen,1
        predict=predict.squeeze(-1)#batch,feaLen,pLen
        predict=predict.transpose(1,2)
        #print("predict shape:",predict.shape)
        """res, (h, c) = self.lstm2(res, (h, c))
        res = torch.reshape(res, [-1, fet])
        res=self.linear2(res).view(batch,seq,fet)"""
        return predict


def train(dataloader,model,loss_fn,optimizer,pLen,device):
    size = len(dataloader.dataset)
    model.train()
    for batch, (lx,sx, y,ty,mask) in enumerate(dataloader):
        lx,sx,ty, y= lx.to(device),sx.to(device),ty.to(device), y.to(device)
        # Compute prediction error
        pred = model(lx,sx,ty,pLen)
        maxpred=[]
        maxy=[]
        #print(pred)
        for p,y in zip(pred,y):
            #print(p.shape,y.shape)
            diff=torch.pow(p-y,2)# seqLen,feaLen
            _,maxindex=torch.max(diff,0)
            for index in maxindex:
                maxpred.append(p[index])
                maxy.append(y[index])
        maxpred=torch.cat(maxpred,0)
        maxy=torch.cat(maxy,0)
        loss=loss_fn(maxpred,maxy)
        #loss=loss_fn(pred,y)
        # Backpropagation
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        if batch % 40 == 0:
            loss, current = loss.item(), batch * len(lx)
            #plot(model,X,y,pLen)
            print(f"loss: {loss:>7f}  [{current:>5d}/{size:>5d}]")

def test(dataloader, model, loss_fn,pLen,device):
    num_batches = len(dataloader)
    model.eval()
    test_loss = 0
    with torch.no_grad():
        for lx,sx, y,ty,mask in dataloader:
            lx,sx,ty, y = lx.to(device),sx.to(device),ty.to(device), y.to(device)
            pred = model(lx,sx,ty,pLen)
            test_loss += loss_fn(pred, y).item()
    test_loss /= num_batches
    print(f"Test Error: \n  Avg loss: {test_loss:>8f} \n")
    return test_loss

def loadModel(path,inSize,oSize,hSize,lNum,tSLen,pLen,vLen):
    model = LSTMNeural(inSize, oSize, hSize, lNum,tSLen,pLen,vLen)
    model.load_state_dict(torch.load(path))
    return model

def computeLSMErro(pred,act,mask):#batch,seqlen,fealen
    SMAPEErro=SMAPE(pred[:,:,0],act[:,:,0])
    RMSEErro=RMSE(pred[:,:,0],act[:,:,0])
    MAEErro=MAE(pred[:,:,0],act[:,:,0])
    MAPEErro=MAPE(pred[:,:,0],act[:,:,0])
    MSEErro=MSE(pred[:,:,0],act[:,:,0])
    SMAPEErroMask = SMAPE(pred[:, :, 0], act[:, :, 0],mask[:,:,0])
    RMSEErroMask = RMSE(pred[:, :, 0], act[:, :, 0],mask[:,:,0])
    MAEErroMask = MAE(pred[:, :, 0], act[:, :, 0],mask[:,:,0])
    MAPEErroMask = MAPE(pred[:, :, 0], act[:, :, 0],mask[:,:,0])
    MSEErroMask = MSE(pred[:, :, 0], act[:, :, 0],mask[:,:,0])
    return np.array([SMAPEErro,RMSEErro,MAEErro,MAPEErro,MSEErro]),\
           np.array([SMAPEErroMask,RMSEErroMask,MAEErroMask,MAPEErroMask,MSEErroMask])

def computePeriLoss(pred,act,pmask,omask):
    SMAPEErroMask = SMAPE(pred[:, :, 0], act[:, :, 0], pmask[:, :, 0])
    RMSEErroMask = RMSE(pred[:, :, 0], act[:, :, 0], pmask[:, :, 0])
    MAEErroMask = MAE(pred[:, :, 0], act[:, :, 0], pmask[:, :, 0])
    MAPEErroMask = MAPE(pred[:, :, 0], act[:, :, 0], pmask[:, :, 0])
    MSEErroMask = MSE(pred[:, :, 0], act[:, :, 0], pmask[:, :, 0])
    nmask=pmask & omask
    OSMAPEErroMask = SMAPE(pred[:, :, 0], act[:, :, 0],nmask[:, :, 0])
    ORMSEErroMask = RMSE(pred[:, :, 0], act[:, :, 0], nmask[:, :, 0])
    OMAEErroMask = MAE(pred[:, :, 0], act[:, :, 0], nmask[:, :, 0])
    OMAPEErroMask = MAPE(pred[:, :, 0], act[:, :, 0], nmask[:, :, 0])
    OMSEErroMask = MSE(pred[:, :, 0], act[:, :, 0], nmask[:, :, 0])
    return np.array([SMAPEErroMask,RMSEErroMask,MAEErroMask,MAPEErroMask,MSEErroMask]),\
           np.array([OSMAPEErroMask,ORMSEErroMask,OMAEErroMask,OMAPEErroMask,OMSEErroMask])

def plot(model,dataloader,pLen,device):
    model.eval()
    preds=[]
    acts=[]
    erros=np.zeros(5)
    oerros=np.zeros(5)
    terros=np.zeros(5)
    toerros=np.zeros(5)
    uterros=np.zeros(5)
    utoerros=np.zeros(5)
    count=0
    tcount=0
    tocount=0
    utcount=0
    ocount=0
    batch=0
    silence=1
    for lx,sx,y,ty,mask in dataloader:
        #lx,sx,y,ty,mask=lx.to(device),sx.to(device),y.to(device),ty.to(device),mask.to(device)
        batch=max(batch,lx.shape[0])
        pred=model(lx,sx,ty,pLen)
        silence-=1
        if lx.shape[0]==batch and silence==0:
            preds.append(pred)
            acts.append(y)
            silence=pLen
        ymask=y>-1
        _,erro=computeLSMErro(pred,y,ymask)
        _,oerr=computeLSMErro(pred,y,mask)
        erros+=erro*ymask.sum().item()
        oerros+=oerr*mask.sum().item()
        ocount+=mask.sum().item()
        count+=ymask.sum().item()
        tmask=torch.abs(ty-y)>0.1
        nmask=tmask & mask
        terro,toerr=computePeriLoss(pred,y,tmask,mask)
        terros+=terro * tmask.sum().detach().numpy()
        toerros+=toerr * nmask.sum().detach().numpy()
        tcount+=tmask.sum().item()
        tocount+=nmask.sum().item()


    preds=torch.cat(preds,1)
    preds=preds.reshape([preds.shape[0]*preds.shape[1],preds.shape[2]])
    acts=torch.cat(acts,1)
    acts=acts.reshape(preds.shape)
    if needPlot:
        plt.plot(acts[:500,0].detach().numpy(),label="act")
        plt.plot(preds[:500, 0].detach().numpy(), label="pred")
        plt.legend()
        plt.show()
    erros/=count
    oerros/=ocount
    terros/=tcount
    toerros/=tocount
    print("total-----SMAPE:%f,RMSE:%f,MAE:%f,MAPE:%f,MSE:%f"%(erros[0],erros[1],erros[2],erros[3],erros[4]))
    print("extreme---SMAPE:%f,RMSE:%f,MAE:%f,MAPE:%f,MSE:%f" % (oerros[0], oerros[1], oerros[2], oerros[3], oerros[4]))
    print("total-----SMAPE:%f,RMSE:%f,MAE:%f,MAPE:%f,MSE:%f" % (terros[0], terros[1], terros[2], terros[3], terros[4]))
    print("extreme---SMAPE:%f,RMSE:%f,MAE:%f,MAPE:%f,MSE:%f" % (toerros[0], toerros[1], toerros[2], toerros[3], toerros[4]))
    return erros,oerros

def uniform(data):
    diss=[]
    for item in data:
        maxv=max(item)
        minv=min(item)
        dis=maxv-minv
        diss.append(dis)
        for j in range(len(item)):
            item[j]=(item[j]-minv)/dis
    return data,diss


def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True

def getSeed():
    seed=int(time.time()/2)%(2**32-1)
    return seed


def MyLSTM(data,testData,validate,pLen,tLLen,tSLen,trainChoice,device,seed=-1,lr=0.001):
    if seed==-1:
        seed=getSeed()
    setup_seed(seed)
    print(seed)
    device=torch.device(device)
    batchSize = 200
    iSize = 1
    oSize = 1
    hSize = 80#80
    lNum = 2#2
    dirName=str(tLLen)+"_"+str(tSLen)+"_"+str(pLen)+"_"+str(trainChoice)
    if not os.path.exists(dirName):
        os.mkdir(dirName)
    modelPath = dirName+"/LSTMMaxModTermLongShortTerm"+str(tLLen)+"_"+str(tSLen)+"_"+str(pLen)+"_"\
                +str(trainChoice)+"_"+str(seed)+".pth"
    vLen=len(data[0][trainChoice][0])
    # cpu,disc=uniform(data[0])
    # mem,dism=uniform(data[1])
    if not loadMod:
        model = LSTMNeural(iSize, oSize, hSize, lNum,tSLen,pLen,vLen).to(device)
    else:
        model = loadModel(modelPath, iSize, oSize, hSize, lNum,tSLen,pLen,vLen)
    loss_fn = nn.MSELoss()
    model = model.to(device)
    loss_fn = loss_fn.to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    dataset = myDataset(data, trainChoice,pLen,tLLen,tSLen)
    testset = myDataset(testData, trainChoice,pLen,tLLen,tSLen)
    valiset = myDataset(validate, trainChoice,pLen,tLLen,tSLen)
    #print(len(dataset))
    train_dataloader = DataLoader(dataset, batch_size=batchSize)
    test_dataloader = DataLoader(testset, batch_size=batchSize)
    vali_dataloader = DataLoader(valiset, batch_size=batchSize)
    epochs = 100
    bestLoss = 9999999999999999999
    if needTrain:
        last_loss = 99999999999999999
        count = 0
        for t in range(epochs):
            print(f"Epoch {t + 1}\n-------------------------------")
            train(train_dataloader, model, loss_fn, optimizer, pLen,device)
            test_loss = test(vali_dataloader, model, loss_fn, pLen,device)
            if last_loss < test_loss:
                count += 1
            else:
                count = 0
            if count >= 3:
                break
            last_loss = test_loss
            if test_loss < bestLoss:
                bestLoss = test_loss
                torch.save(model.cpu().state_dict(), modelPath)
                model = model.to(device)
        #print("Done!")
        #print("Saved PyTorch Model State to " + modelPath)
    model=loadModel(modelPath, iSize, oSize, hSize, lNum,tSLen,pLen,vLen)
    #model=model.to(device)
    erros,oerros=plot(model, test_dataloader, pLen,device)
    with open(dirName+"/res"+str(seed)+".csv","w") as f:
        f.write("%f,%f,%f\n"%(erros[3],erros[4],erros[2]))
        f.write("%f,%f,%f\n"%(oerros[3],oerros[4],oerros[2]))
    return (erros,oerros,seed)



