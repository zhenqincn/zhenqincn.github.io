import csv
import json
import numpy as np
import os
import matplotlib.pyplot as plt
import torch
import pandas as pd
from statsmodels.tsa.stattools import acf

def getJsonData(root):
    threshold = 500
    with open(root,'r') as f:
        lines=f.readlines()
    cpu=[]
    memory=[]
    instancec=[]
    instancem=[]
    lastInex=-1
    for line in lines:
        record=json.loads(line)
        if record['instance_index']!=lastInex and lastInex!=-1:
            if len(instancec)!=0 and len(instancec)>=threshold:
                cpu.append(instancec)
                memory.append(instancem)
            instancem=[]
            instancec=[]
        lastInex = record['instance_index']
        instancec.append(record['average_usage']['cpus'])
        instancem.append(record['average_usage']['memory'])
    #cpu=pd.DataFrame(cpu)
    #memory=pd.DataFrame(memory)
    if len(instancec)!=0 and len(instancec)>=threshold:
        cpu.append(instancec)
        memory.append(instancem)
    return (cpu,memory)

def getSMDData(dataPath,rootPath,type):
    existFile=os.listdir(rootPath)
    if type+".npy" in existFile:
        return np.load(rootPath+type+".npy",allow_pickle=True)*100
    #dataPath = "ServerMachineDataset/test/"
    file_names=os.listdir(dataPath)
    file_names=sorted(file_names)
    datas=[]
    for name in file_names:
        file_name=dataPath+name
        temp = np.genfromtxt(file_name,dtype=np.float32,delimiter=',')
        print(temp.shape)
        datas.append(temp)
    datas=np.array(datas,dtype=object)
    np.save(rootPath+type+".npy",datas)
    return datas*100


def getDataDimension(datas):
    ndatas0=[]
    ndatas1=[]
    for data in datas:
        ndatas0.append(data[:,0])
        ndatas1.append(data[:,1])
    return (ndatas0,ndatas1)


def getACORNData(root):
    with open(root, 'r') as f:
        datas = f.read().split('\n')[1:]
    for i in range(len(datas)):
        datas[i] = float(datas[i].split(',')[-1])
    maxData=max(datas)
    datas=np.array(datas)
    datas=datas/maxData *100
    machine = [datas]
    datasets = [machine, machine]
    return datasets

def getPowerPlant(root):
    datas = pd.read_csv(root)
    data0 = datas['AT'].to_numpy()
    m0=np.max(data0)
    data0=((data0)/m0)*100
    data1 = datas['EV'].to_numpy()
    m1=np.max(data1)
    data1=((data1)/m1)*100
    datas = [[data0], [data1]]
    return datas

def getCsvData(root):
    cpu=[]
    memory=[]
    with open(root,'r') as f:
        reader= csv.reader(f)
        lastMach=-1
        citem=[]
        mitem=[]
        lines=0
        for item in reader:
            if item[0]!=lastMach:
                if len(citem)>0:
                    cpu.append(citem)
                    memory.append(mitem)
                lastMach=item[0]
                citem=[]
                mitem=[]
            try:
                lines+=1
                citem.append(float(item[2]))
                mitem.append(float(item[3]))
            except(ValueError):
                print("line:%d valueError:%s,%s"%(lines,item[2],item[3]))
        if len(citem)>0:
            cpu.append(citem)
            memory.append(mitem)
    return (cpu,memory)


def getNewDatas(datas,winSize,dataLen):
    ndatas=[]
    for data in datas:
        data=np.array(data)
        ndata=[]
        for d in range(dataLen):
            ndata.append(np.mean(data[d:d+winSize]))
        ndatas.append(ndata)
    ndatas=np.array(ndatas)
    return ndatas

def checkPeak(ac,i,checkRange):
    for j in range(1,checkRange+1):
        if ac[i]<=ac[i+j] or ac[i]<=ac[i-j]:
            return False
    return True

def getTerm(datas,winLen=100,type="cpu"):
    Tlen=[]
    checkRange = 20
    if type=="cpu":
        threshold=0.2
    else:
        threshold=0.4
    for data in datas:
        if type=="cpu":
            data=data[1000:]
        else:
            data=data[1000:]
        datamean=[]
        for i in range(len(data)-winLen):
            datamean.append(np.mean(data[i:i+winLen]))
        if len(datamean)==0:
            Tlen.append(0)
            continue
        ac = acf(datamean, nlags=len(datamean))
        flag = False
        for i in range(checkRange, len(ac) - checkRange):
            if checkPeak(ac,i,checkRange) and ac[i] > threshold:
                Tlen.append(i)
                flag = True
                break
        if not flag:
            Tlen.append(0)
    return Tlen


def getDataSetTerm(datasets):
    cpuTerm=getTerm(datasets[0],type="cpu")
    memTerm=getTerm(datasets[1],type="mem")
    return (cpuTerm,memTerm)


def computeDis(a,b):
    a=np.array(a)
    b=np.array(b)
    return np.power(a-b,2).sum()

def getDataSetComponet(pLen,tLen,term,misLen,datas):
    x=[]
    y=[]
    ty=[]
    mask=[]
    for i,data in enumerate(datas):
        start=0
        mean=np.mean(data)
        std=np.std(data)
        while start+tLen+pLen<len(data):
            x.append(data[start:start+tLen])
            base=start+tLen
            start+=pLen
            y.append(data[base:base+pLen])
            mask.append(data[base:base+pLen]>mean+std)
            mindis=9999999999999
            typos=-1
            if len(term[i])!=0:
                for j in range(tLen,len(term[i])-pLen):
                    #print("%d:%d,%d:%d/%d"%(j-tLen,j,start-tLen,start,len(term[i])))
                    dis=computeDis(term[i][j-tLen:j],data[start-pLen:start-pLen+tLen])
                    if dis<mindis:
                        mindis=dis
                        typos=j
                if typos!=-1:
                    ty.append(term[i][typos:typos+pLen])
                else:
                    print("fail to find minimize distance")
                    exit(-1)
            else:
                ty.append([-1]*pLen)
    x=np.array(x,dtype=np.float32)
    y=np.array(y,dtype=np.float32)
    ty=np.array(ty,dtype=np.float32)
    mask=np.array(mask)
    return x,y,ty,mask


def divideDataset(datas,pLen,tLen,term,misLen):
    cx,cy,cty,cmask=getDataSetComponet(pLen,tLen,term[0],misLen,datas[0])
    mx,my,mty,mmask=getDataSetComponet(pLen,tLen,term[1],misLen,datas[1])
    return [cx,mx],[cy,my],[cty,mty],[cmask,mmask]


def sample(data):
    sampleData = []
    step = 0
    stride = 20
    while step < len(data):
        sampleData.append(data[step])
        step += stride  # math.ceil(math.sqrt(math.pow(math.e,stride)))
        stride += 1
    return sampleData

def getDataSetWithSample(pLen,tLLen,tSLen,term,datas):
    print("pLen:%d"%pLen)
    print(len(datas))
    lx=[]
    sx=[]
    y=[]
    ty=[]
    mask=[]
    for i,data in enumerate(datas):
        start=tSLen
        mean=np.mean(data)
        std=np.std(data)
        while start+tLLen+pLen<len(data):
            lx.append(sample(data[start:start+tLLen]))
            base=start+tLLen
            sx.append(data[base-tSLen:base])
            start+=1
            y.append(data[base:base+pLen])
            mask.append(data[base:base+pLen]>mean+std)
            mindis=9999999999999
            typos=-1
            if len(term[i])>=pLen:
                for j in range(tLLen,len(term[i])-pLen):
                    #print("%d:%d,%d:%d/%d"%(j-tLen,j,start-tLen,start,len(term[i])))
                    dis=computeDis(term[i][j-tLLen:j],data[start-2:start-2+tLLen])
                    if dis<mindis:
                        mindis=dis
                        typos=j
                if typos!=-1:
                    ty.append(term[i][typos+1:typos+1+pLen])
                else:
                    print("fail to find minimize distance,dataLen:%d,termLen:%d"%(len(term[i])-pLen-tLLen,len(term[i])))
                    #exit(-1)
                    if base-len(term[i])>=0 and base+pLen-len(term[i])<len(data):
                        ty.append(data[base-len(term[i]):base+pLen-len(term[i])])
                    else:
                        ty.append([-1]*pLen)
            else:
                ty.append([-1]*pLen)
    lx=np.array(lx,dtype=np.float32)
    sx=np.array(sx,dtype=np.float32)
    y=np.array(y,dtype=np.float32)
    ty=np.array(ty,dtype=np.float32)
    mask=np.array(mask)
    return lx,sx,y,ty,mask


def divideDatasetSample(datas,pLen,tLLen,tSLen,term):
    clx,csx,cy,cty,cmask=getDataSetWithSample(pLen,tLLen,tSLen,term[0],datas[0])
    mlx,msx,my,mty,mmask=getDataSetWithSample(pLen,tLLen,tSLen,term[1],datas[1])
    return [clx,mlx],[csx,msx],[cy,my],[cty,mty],[cmask,mmask]

def windowMean(datas,neighborNum):
    datas=datas[1:-1]
    minLen=99999999
    for data in datas:
        if len(data)<minLen:
            minLen=len(data)
    ntest=[]
    trLen=int(0.9*minLen)
    teLen=minLen-trLen
    ndatas=getNewDatas(datas,100,minLen)
    tdatas=getNewDatas(datas,1,trLen-1)
    corr=np.corrcoef(ndatas)
    Tlen=[]
    maxT=-2
    acs=[]
    for ndata in ndatas:
        ac=acf(ndata,nlags=len(ndata))
        flag=False
        for i in range(1,len(ac)-1):
            if ac[i-1]<ac[i] and ac[i]>ac[i+1] and ac[i]>0.2:
                Tlen.append(i)
                acs.append(ac[i])
                flag=True
                if i>maxT:
                    maxT=i
                break
        if not flag:
            Tlen.append(0)
    tdatas=tdatas[:,:-maxT]
    for data in datas:
        ntest.append(data[trLen-maxT:trLen+teLen])
    ntest=np.array(ntest)
    """plt.imshow(corr)
    plt.show()
    plt.plot(acf(ndatas[0],nlags=len(ndatas[0])))
    plt.show()"""
    corr=torch.tensor(corr,dtype=torch.float)
    return tdatas,corr,Tlen,ntest,acs

def winData(datas):
    datas = datas[1:-1]
    minLen = 99999999
    for data in datas:
        if len(data) < minLen:
            minLen = len(data)
    trLen = int(0.9 * minLen)
    trdata=[]
    tsdata=[]
    for data in datas:
        trdata.append(data[:trLen])
        tsdata.append(data[trLen:minLen])
    trdata=np.array(trdata)
    tsdata=np.array(tsdata)
    return trdata,tsdata

def windowMeanLstm(datas):
    minLen=999999
    for data in datas[0]:
        if len(data)<minLen:
            minLen=len(data)
    ndatas=[]
    winLen=10
    for item in datas:
        nitem=[]
        for data in item:
            ndata=[]
            for i in range(minLen-winLen):
                ndata.append(np.mean(data[i:i+winLen]))
            nitem.append(ndata)
        ndatas.append(nitem)
    ndatas=np.array(ndatas)
    print(ndatas.shape)

def computeErro(preds,acts,mask):# shape (,,...,seqlen)
    mul=1
    for s in acts.shape:
        mul*=s
    nonzeroMask=acts!=0
    error=(np.fabs(acts[nonzeroMask]-preds[nonzeroMask])/acts[nonzeroMask]).sum()/(mul)
    seqlen=preds.shape[-1]
    preds=preds.reshape([-1,seqlen])
    acts=acts.reshape([-1,seqlen])
    if mask.sum()!=0:
        oerror=(np.fabs(acts[mask]-preds[mask])/acts[mask]).sum()/mask.sum()
    else:
        oerror=0
    return (error,oerror)

"""def divideTrainAndTest(datas):
    train=[]
    test=[]
    for data in datas:
        if len(data)>2000:
            trlen=len(data)-2000
            if len(data)>2510:
                train.append(data[:trlen])
            train.append(data[trlen+1000:])
            test.append(data[trlen:trlen+1000])
    return train,test"""
def divideTrainAndTest(datas,threshold=5000):
    train=[]
    test=[]
    validate=[]
    for data in datas:
        if len(data)>threshold:
            test.append(data[:500])
            validate.append(data[500:1000])
            train.append(data[1000:])
    return train,test,validate


def divideTrainAndTestNormalize(datas):
    train=[]
    test=[]
    validate=[]
    means=[]
    stds=[]
    for data in datas:
        if len(data)>5000:
            te=data[:1500]
            val=data[1500:3000]
            tr=data[3000:]
            mean=np.mean(tr)
            std=np.std(tr)
            if std==0:
                std=1
            means.append(mean)
            stds.append(std)
            te=(te-mean)/std
            tr=(tr-mean)/std
            val=(val-mean)/std
            test.append(te)
            validate.append(val)
            train.append(tr)
    return train,test,validate,means,stds


def getDataSetNormalize(datas):
    c,m=datas[0],datas[1]
    mtr,mte,mv,mmeans,mstds=divideTrainAndTestNormalize(m)
    ctr,cte,cv,cmeans,cstds=divideTrainAndTestNormalize(c)
    return [ctr,mtr],[cte,mte],[cv,mv],[cmeans,mmeans],[cstds,mstds]


def getDataSet(datas,threshold=5000):
    c,m=datas[0],datas[1]
    mtr,mte,mv=divideTrainAndTest(m,threshold)
    ctr,cte,cv=divideTrainAndTest(c,threshold)
    return [ctr,mtr],[cte,mte],[cv,mv]

def getCompleteTerm(Tlen,cut):
    if Tlen<=0:
        return cut
    start=Tlen
    while start<cut:
        start+=Tlen
    return start

def divideTrainAndTestTerm(datas,Tlen):
    train=[]
    test=[]
    validate=[]
    term=[]
    for i,data in enumerate(datas):
        if len(data)>Tlen[i]+1000:
            test.append(data[:500])
            validate.append(data[500:1000])
            term.append(data[1000:1000+Tlen[i]])
            train.append(data[Tlen[i]+1000:])
    return train,test,validate,term

def getDataSetWithTerm(datas,Tlen):
    c, m = datas[0], datas[1]
    mtr, mte, mv,mterm = divideTrainAndTestTerm(m,Tlen[1])
    ctr, cte, cv,cterm = divideTrainAndTestTerm(c,Tlen[0])
    return [ctr, mtr], [cte, mte], [cv, mv], [cterm,mterm]

def MAE(pred,act,mask=None):#batch,seqLen
    if mask==None:
        mask=torch.ones(pred.shape,dtype=torch.bool)
    if mask.sum()==0:
        return 0
    with torch.no_grad():
        return torch.mean(torch.abs(pred[mask]-act[mask])).item()


def MAPE(pred,act,mask=None):#batch,seqLen
    if mask==None:
        mask=torch.ones(pred.shape,dtype=torch.bool)
    NonZeroMask=act>0
    mask = NonZeroMask & mask
    if mask.sum()==0:
        return 0
    with torch.no_grad():
        return torch.mean(torch.abs(pred[mask]-act[mask])/torch.abs(act[mask])).item()


def MSE(pred,act,mask=None):#batch,seqLen
    if mask==None:
        mask=torch.ones(pred.shape,dtype=torch.bool)
    if mask.sum()==0:
        return 0
    with torch.no_grad():
        return torch.mean(torch.pow(pred[mask]-act[mask],2)).item()


def RMSE(pred,act,mask=None):#batch,seqLen
    if mask==None:
        mask=torch.ones(pred.shape,dtype=torch.bool)
    if mask.sum() == 0:
        return 0
    with torch.no_grad():
        return torch.sqrt(torch.mean(torch.pow(pred[mask]-act[mask],2))).item()


def SMAPE(pred,act,mask=None):#batch,seqLen
    if mask==None:
        mask=torch.ones(pred.shape,dtype=torch.bool)
    NonZeroMask=act>0
    mask=NonZeroMask & mask
    if mask.sum()==0:
        return 0
    with torch.no_grad():
        return torch.mean(torch.abs(pred[mask]-act[mask])/((torch.abs(pred[mask])+torch.abs(act[mask]))/2)).item()


def readDina(path):
    with open(path) as f:
        lines = f.readlines()
    loads = []
    for line in lines:
        item = line.split('\t')
        load = float(item[1].strip('\n'))*100
        loads.append(load)
    loadsc=loads[:]
    return [[loads],[loadsc]]

def readWiki(path):
    #"D:\GoogleData\currenttmp"
    datas=[]
    winSize = 100
    files=os.listdir(path)
    for file in files:
        lasttime = -winSize
        machine=[]
        fpath=path+file
        with open(fpath,"rb") as f:
            lines=f.readlines()
        for line in lines:
            line=str(line)
            line=line.split(' ')
            time=float(line[1])
            print(line)
            if time>=int(lasttime)+winSize:
                machine.append(1)
            else:
                machine[-1]+=1
            lasttime=time
        datas.append(machine)
    datas=np.array(datas)
    np.save(path+"wiki.npy",datas)
    return datas

def readWikiNpy(path):
    datas=np.load(path)
    return datas